package br.furb.aula.poo.gerenciamentoVendedores;

public class Vendedor {
	
	private String nome;
	private double salarioBase;
	private double valorVendas;
	private Endereco endereco; //endereco se torna atributo da classe Vendedor
	
	/**
	
	'Endereco' aparece como atributo do construtor da classe Vendedor devido à navegabilidade 
	(unidirecional apontando para Endereco) e à multiplicidade (1..1)
	
	-> Ambas características unidas demonstram que um Vendedor não pode existir de forma válida 
	sem exatamente 1 Endereco.
	
	**/
	
	public Vendedor(String nome, double salarioBase, double valorVendas, Endereco endereco) {
		setNome(nome);
		setSalarioBase(salarioBase);
		setValorVendas(valorVendas);
		setEndereco(endereco);
	}
	
	//Métodos com dependência à outra classe
	
	//No parâmetro
	 public void setEndereco(Endereco endereco) {
		 if(endereco==null) {
				throw new IllegalArgumentException("Endereco invalido");
		}
		this.endereco = endereco;
	 }
	 
	 //No retorno
	 public Endereco getEndereco() {
		 return this.endereco;
	 }
	 //
	 
	 public double calcularComissao() {
		 return valorVendas*0.10;
	 }
	 
	 public double calcularSalario() {
		 double comissao = calcularComissao();
		 return salarioBase+comissao;
	 }
	 
	 //Encapsulamento - Getters e Setters
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		if(nome==null || nome.isBlank()) {
			throw new IllegalArgumentException("Nome invalido");
		}
		this.nome = nome;
	}
	
	public double getSalarioBase() {
		return salarioBase;
	}
	public void setSalarioBase(double salarioBase) {
		if(salarioBase<1412) {
			throw new IllegalArgumentException("Salario invalido");
		}
		this.salarioBase = salarioBase;
	}
	
	public double getValorVendas() {
		return valorVendas;
	}
	public void setValorVendas(double valorVendas) {
		if(valorVendas<0) {
			throw new IllegalArgumentException("Valor de vendas invalido");
		}
		this.valorVendas = valorVendas;
	}
	
	

}
