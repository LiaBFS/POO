package br.furb.aula.poo.gerenciamentoVendedores;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ) {
        
    	Endereco e1 = new Endereco("Rua para o v1", 11, "11111-1111");
    	Endereco e2 = new Endereco("Rua para o v2", 22, "22222-2222");
    	Endereco e3 = new Endereco("Rua para o v3", 33, "33333-3333");
    	Endereco e4 = new Endereco("Rua para o v4", 44, "44444-4444");
    	
    	Vendedor v1 = new Vendedor("José Um", 1500, 620, e1);
    	Vendedor v2 = new Vendedor("Ana Dois", 1412, 500, e2);
    	Vendedor v3 = new Vendedor("Vitor Tres", 1450, 760, e3);
    	Vendedor v4 = new Vendedor("Bia Quatro", 2500, 300, e4);
    	
    	Loja loja = new Loja("loja teste");
    	loja.adicionarVendedor(v1);
    	loja.adicionarVendedor(v2);
    	loja.adicionarVendedor(v3);
    	loja.adicionarVendedor(v4);
    	
    	
    	for(Vendedor v : loja.getVendedores()) {
    		System.out.println("Nome: "+v.getNome());
    		System.out.println("Salario base: "+v.getSalarioBase());
    		System.out.println("Vendas: "+v.getValorVendas());
    		System.out.println("Comissao: "+v.calcularComissao());
    		System.out.println("Salario: "+v.calcularSalario());
    		System.out.println("---");
    	}
    	
    	System.out.println("Media de comissao da loja: "+ loja.calcularMediaComissao());
    	System.out.println("Vendedor com a maior venda: "+ loja.vendedorMaiorVenda().getNome());
    	System.out.println("Folha de pagamento: "+ loja.calcularFolhaPagamento());
    	
    	
    }
}
