package br.furb.aula.poo.gerenciamentoVendedores;

public class Endereco {
	
	private String logradouro;
	private int numero;
	private String cep;
	
	/**
	Como Endereco não aponta para nenhuma classe no diagrama, simboliza que não deve ter acesso
	a elas.
	**/
	
	public Endereco(String logradouro, int numero, String cep) {
		setLogradouro(logradouro);
		setNumero(numero);
		setCep(cep);
	}
	
	//Encapsulamento - Getters e Setters
	/**Validações:
	 
	 if(coisa que vc não quer que aconteça) {
		throw new IllegalArgumentException("coisa inválida");
	}
	
	**/
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		if(logradouro==null || logradouro.isBlank()) {
			throw new IllegalArgumentException("Logradouro invalido");
		}
		this.logradouro = logradouro;
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		if(numero<=0) {
			throw new IllegalArgumentException("Número invalido");
		}
		this.numero = numero;
	}
	
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		if(cep==null || cep.isBlank()) {
			throw new IllegalArgumentException("Cep invalido");
		}
		this.cep = cep;
	}
	
	

}
