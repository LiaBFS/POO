package br.furb.aula.poo.gerenciamentoVendedores;

import java.util.ArrayList;

public class Loja {
	
	private String nome;
	private ArrayList<Vendedor> vendedores; //criando o Array como atributo da classe

	public Loja(String nome) {
		setNome(nome);
		
		//inicializando Array
		vendedores = new ArrayList();
	}
	
	//Métodos com dependência à outra classe
	
	//No parâmetro
	public void adicionarVendedor(Vendedor vendedor) {
		if(vendedor==null) {
			throw new IllegalArgumentException("Vendedor invalido");
		}
		vendedores.add(vendedor);
	}
	
	public void removerVendedor(Vendedor vendedor) {
		if(vendedor==null) {
			throw new IllegalArgumentException("Vendedor invalido");
		}
		if(vendedores.isEmpty()) {
			throw new IllegalArgumentException("Sem vendedores");
		}
		vendedores.remove(vendedor);
	}

	//No retorno
	public ArrayList<Vendedor> getVendedores(){
		return vendedores;
	}
	
	public Vendedor vendedorMaiorVenda() {
		Vendedor maior = vendedores.get(0);
		
		// A sintaxe do : simboliza um "for each"
		// Basicamente -> Para cada [Tipo] chamado [elemento] dentro do array, faça [ação]
		
		for(Vendedor v: vendedores) {
			if(v.getValorVendas()>maior.getValorVendas()) {
				maior = v;
			}
		}
		
		return maior;
	}
	//
	
	public double calcularMediaComissao() {
		double soma=0;
		
		for(Vendedor v : vendedores) {
			soma += v.calcularComissao();
		}
		
		return soma/vendedores.size();
	}
	
	public double calcularFolhaPagamento() {
		double somaSalarios=0;
		
		for(Vendedor v : vendedores) {
			somaSalarios += v.calcularSalario();
		}
		
		return somaSalarios;
	}
	
	//Encapsulamento - Getters e Setters
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		if(nome==null || nome.isBlank()) {
			throw new IllegalArgumentException("Nome invalido");
		}
		this.nome = nome;
	}
	
	

}
